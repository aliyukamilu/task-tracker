import React from "react";
import Tableheader from "./Tableheader";
import Header from './Header'

const Home = () => {
  return (
    <div className="">
      <Header />
      <Tableheader />
    </div>
  );
};

export default Home;
