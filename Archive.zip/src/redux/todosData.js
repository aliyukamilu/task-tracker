export const todosData = [
  {
    id: Math.floor(Math.random() * 1000),
    item: 'todo',
    date: '2022-11-23',
    time: '12:43',
    details: 'this is default task',
    status: 'Ongoing',
  },
  {
    id: Math.floor(Math.random() * 1000),
    item: 'todo2',
    date: '2022-11-22',
    time: '12:43',
    details: 'this is default task 2',
    status: 'Done',
  },
  {
    id: Math.floor(Math.random() * 1000),
    item: 'todo2',
    date: '2022-11-22',
    time: '12:43',
    details: 'this is default task 2',
    status: 'Done',
  },
  {
    id: Math.floor(Math.random() * 1000),
    item: 'todo2',
    date: '2022-11-22',
    time: '12:43',
    details: 'this is default task 2',
    status: 'Done',
  }
]